﻿using System;

namespace RecipeApp
{
    class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
    }

    class RecipeStep
    {
        public string Description { get; set; }
    }

    class Recipe
    {
        private Ingredient[] originalIngredients; // To store original ingredient quantities

        private Ingredient[] ingredients;
        private RecipeStep[] steps;

        public void AddIngredients()
        {
            Console.WriteLine("Enter the number of ingredients:");
            int ingredientCount = Convert.ToInt32(Console.ReadLine());
            ingredients = new Ingredient[ingredientCount];
            originalIngredients = new Ingredient[ingredientCount];

            for (int i = 0; i < ingredientCount; i++)
            {
                Console.WriteLine($"Enter ingredient {i + 1} details:");
                Console.Write("Name: ");
                string name = Console.ReadLine();
                Console.Write("Quantity: ");
                double quantity = Convert.ToDouble(Console.ReadLine());
                Console.Write("Unit: ");
                string unit = Console.ReadLine();

                ingredients[i] = new Ingredient { Name = name, Quantity = quantity, Unit = unit };
                originalIngredients[i] = new Ingredient { Name = name, Quantity = quantity, Unit = unit }; // Store original quantities
            }
        }

        public void AddSteps()
        {
            Console.WriteLine("Enter the number of steps:");
            int stepCount = Convert.ToInt32(Console.ReadLine());
            steps = new RecipeStep[stepCount];

            for (int i = 0; i < stepCount; i++)
            {
                Console.WriteLine($"Enter step {i + 1} description:");
                string description = Console.ReadLine();

                steps[i] = new RecipeStep { Description = description };
            }
        }

        public void DisplayRecipe()
        {
            Console.WriteLine("Recipe:");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }

            Console.WriteLine("\nSteps:");
            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i].Description}");
            }
        }

        // Scaling method to scale the ingredient quantities by a factor
        public void ScaleRecipe(double factor)
        {
            foreach (var ingredient in ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        // Reset method to reset the ingredient quantities to the original values
        public void ResetRecipe()
        {
            for (int i = 0; i < ingredients.Length; i++)
            {
                ingredients[i].Quantity = originalIngredients[i].Quantity;
            }
        }

        // Clear method to clear all recipe data
        public void ClearRecipe()
        {
            ingredients = null;
            steps = null;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Ask for the number of guests
            Console.Write("How many guests are coming? ");
            int numberOfGuests = Convert.ToInt32(Console.ReadLine());

            Recipe recipe = new Recipe();

            // Take user input for adding ingredients and steps
            recipe.AddIngredients();
            recipe.AddSteps();

            // Display the recipe
            recipe.DisplayRecipe();

            // Additional functionality
            Console.WriteLine("\nAdditional functionalities:");
            Console.WriteLine("1. Scale the recipe (0.5 for half, 2 for double, 3 for triple)");
            Console.WriteLine("2. Reset quantities to original values");
            Console.WriteLine("3. Clear all data to enter a new recipe");

            Console.Write("\nEnter your choice: ");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.Write("Enter scaling factor: ");
                    double factor = Convert.ToDouble(Console.ReadLine());
                    recipe.ScaleRecipe(factor);
                    Console.WriteLine("\nRecipe scaled successfully.");
                    recipe.DisplayRecipe();
                    break;
                case 2:
                    recipe.ResetRecipe();
                    Console.WriteLine("\nQuantities reset to original values.");
                    recipe.DisplayRecipe();
                    break;
                case 3:
                    recipe.ClearRecipe();
                    Console.WriteLine("\nRecipe data cleared. Enter a new recipe.");
                    recipe.AddIngredients();
                    recipe.AddSteps();
                    recipe.DisplayRecipe();
                    break;
                default:
                    Console.WriteLine("\nInvalid choice.");
                    break;
            }

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}

